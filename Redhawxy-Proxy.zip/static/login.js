//Replace wow123 with your password
var pw = "wow123"

function login() {
  var pass = document.getElementById('pass').value
  document.getElementById('pass').value=""
  if (pass == pw) {
    document.getElementById('search').style=""
    document.getElementById('pass').style="display: None;"
    document.getElementById('btn').style="display: None;"
    alert("Login Successful, You May Now Access The Full Site")
  }else {
    alert("Login Failed, Try Again")
  }
}